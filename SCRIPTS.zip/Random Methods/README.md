# L7 Methods
 Just some basic layer 7 methods, some still work well. 🤠